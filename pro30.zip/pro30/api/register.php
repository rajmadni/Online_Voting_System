<?php
include("connection.php");

$name = $_POST['name'];
$mobile = $_POST['mob'];
$pass = $_POST['pass'];
$cpass = $_POST['cpass'];
$add = $_POST['add'];
$image = $_FILES['image']['name'];
$tmp_name = $_FILES['image']['tmp_name'];
$image_size = $_FILES['image']['size']; // Get image size in bytes
$role = $_POST['role'];

// Validate input
if ($cpass != $pass) {
    echo '<script>
            alert("Passwords do not match!");
            window.location = "../routes/register.php";
          </script>';
    exit();
}

if (strlen($pass) < 8) {
    echo '<script>
            alert("Password must be at least 8 characters long.");
            window.location = "../routes/register.php";
          </script>';
    exit();
}

if (!preg_match('/^\d{10}$/', $mobile)) {
    echo '<script>
            alert("Mobile number must be exactly 10 digits.");
            window.location = "../routes/register.php";
          </script>';
    exit();
}

// Validate image size (max 5MB)
if ($image_size > 5 * 1024 * 1024) {
    echo '<script>
            alert("Image size must not exceed 5MB.");
            window.location = "../routes/register.php";
          </script>';
    exit();
}

// Move uploaded image and insert data
move_uploaded_file($tmp_name, "../uploads/$image");
$insert = mysqli_query($connect, "INSERT INTO user (name, mobile, password, address, photo, status, votes, role) 
                                  VALUES('$name', '$mobile', '$pass', '$add', '$image', 0, 0, '$role')");

if ($insert) {
    echo '<script>
            alert("Registration successful!");
            window.location = "../";
          </script>';
} else {
    echo '<script>
            alert("Registration failed. Try again!");
            window.location = "../routes/register.php";
          </script>';
}
?>
